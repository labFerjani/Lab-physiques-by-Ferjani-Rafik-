# Labo Physique – Ferjani Rafik

Android Studio project wrapping the supplied offline HTML laboratory in a local WebView.
See `README_AR.md` for build and release instructions.
