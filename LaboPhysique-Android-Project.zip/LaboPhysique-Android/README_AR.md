# Labo Physique – Ferjani Rafik (Android)

هذا مشروع Android يعتمد WebView لعرض نسخ HTML المحلية المضمنة داخل التطبيق، ويعمل دون اتصال بالإنترنت بعد التثبيت.

## البناء
- يتطلب Java 17 وAndroid SDK 36 وGradle 8.13.
- ملف GitHub Actions موجود في `.github/workflows/android-build.yml`.
- ينتج `assembleDebug` ملف APK للاختبار.
- ينتج `bundleRelease` ملف AAB؛ يجب توقيعه بمفتاح إصدار خاص قبل رفعه إلى Google Play.

## الحزمة المحلية
توجد صفحات المختبر داخل `app/src/main/assets/`، والصفحة الرئيسية هي `index.html`.

## تنبيه
لا تشارك ملف مفتاح التوقيع أو كلمات مروره. احتفظ بنسخة احتياطية آمنة من مفتاح الإصدار؛ تحديث التطبيق المنشور يتطلب استخدام المفتاح نفسه أو مفتاح ترقية معتمد من Google Play.
